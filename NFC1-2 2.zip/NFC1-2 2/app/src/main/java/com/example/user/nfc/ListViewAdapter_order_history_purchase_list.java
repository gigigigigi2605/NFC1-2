package com.example.user.nfc;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.user.nfc.ListVO.ListVO_order_history_purchase_list;

import java.util.ArrayList;

public class ListViewAdapter_order_history_purchase_list extends BaseAdapter {

    private ArrayList<ListVO_order_history_purchase_list> listVO = new ArrayList<ListVO_order_history_purchase_list>();

    public ListViewAdapter_order_history_purchase_list() {

    }

    @Override
    public int getCount() {
        return listVO.size();
    }

    // ** 이 부분에서 리스트뷰에 데이터를 넣어줌 **
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //postion = ListView의 위치      /   첫번째면 position = 0
        final int pos = position;
        final Context context = parent.getContext();


        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.custom_listview, parent, false);
        }
        TextView Menu_name = (TextView) convertView.findViewById(R.id.Menu_name);
        TextView Count = (TextView) convertView.findViewById(R.id.count);
        TextView Price = (TextView) convertView.findViewById(R.id.price);


        ListVO_order_history_purchase_list listViewItem = listVO.get(position);

        // 아이템 내 각 위젯에 데이터 반영
        Menu_name.setText(listViewItem.getMenu_name());
        Count.setText(listViewItem.getcount());
        Price.setText(listViewItem.getpirce());


        return convertView;
    }


    @Override
    public long getItemId(int position) {
        return position;
    }


    @Override
    public Object getItem(int position) {
        return listVO.get(position);
    }

    // 데이터값 넣어줌
    public void addVO(int count, String Menu_name, int pirce) {
        ListVO_order_history_purchase_list item = new ListVO_order_history_purchase_list();

        item.setMenu_name(Menu_name);
        item.setcount(count);
        item.setPrice(pirce);

        listVO.add(item);
    }
}


