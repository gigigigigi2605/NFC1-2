package com.example.user.nfc;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter {
    private MainActivity activity;
    ArrayList<Menu> menus;

    ListViewAdapter(MainActivity activity) {
        this.activity = activity;
        menus = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return menus.size();
    }

    @Override
    public Object getItem(int i) {
        return menus.get(i);
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @SuppressLint("DefaultLocale")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        RelativeLayout layout;
        /*if (view == null) {
            LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.custom_listview, viewGroup, false);
            layout = (RelativeLayout) view;
        } else {
            layout = (RelativeLayout) view;
        }

        Menu menu = menus.get(i);

        TextView tvName = layout.findViewById(R.id.Menu_name);
        tvName.setText(menu.name);

        ImageView ivPicture = layout.findViewById(R.id.Menu_picture);
        Glide.with(activity).load(menu.picture).into(ivPicture);

        TextView tvTag = layout.findViewById(R.id.hash_tag);
        tvTag.setText(menu.tag);

        DecimalFormat format = new DecimalFormat("###,###");
        TextView tvPrice = layout.findViewById(R.id.price);
        tvPrice.setOnClickListener(activity);
        tvPrice.setTag(menu);
        tvPrice.setText(String.format("%s원", format.format(menu.price)));
        if (activity.menus.contains(menu)) {
            tvPrice.setTextColor(activity.getResources().getColor(android.R.color.holo_red_light));
        } else {
            tvPrice.setTextColor(activity.getResources().getColor(android.R.color.black));
        }

        TextView tvGreatCount = (TextView) layout.findViewById(R.id.great_count);
        tvGreatCount.setText(String.valueOf(menu.likeCount));

        Button btnGreat = (Button) layout.findViewById(R.id.great_button);
        btnGreat.setOnClickListener(activity);
        btnGreat.setTag(menu);

        return layout;*/
        return  view;
    }


    public void add(JSONObject object) {
        try {
            menus.add(new Menu(object.getInt("_index"), object.getInt("price"), object.getInt("visibility"), object.getInt("count"),
                    object.getString("picture"), object.getString("name"), object.getString("tag")));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void clear() {
        menus.clear();
    }
}
