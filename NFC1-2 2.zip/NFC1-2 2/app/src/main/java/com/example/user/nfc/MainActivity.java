package com.example.user.nfc;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.ssomai.android.scalablelayout.ScalableLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.NetworkInterface;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import be.appfoundry.nfclibrary.activities.NfcActivity;

public class MainActivity extends NfcActivity implements View.OnClickListener, AdapterView.OnItemClickListener {
    private Activity activity;

    ListView lv;
    GridView gv;
    ListViewAdapter adapter;
    ListViewAdapter_Grid adapterGrid;
    ArrayList<Menu> menus;

    int _index = 0;
    String macAddress, token;

    long millis = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // 화면 전환 - 인텐트 날리기 (startActivity)
        //     1. 다음 넘어갈 화면을 준비한다 (layout xml, java)
        //    2. AndroidManifest.xml 에 Activity 를 등록한다
        //    3. Intent 객체를 만들어서 startActivity 한다

        ImageButton b1 = (ImageButton)findViewById(R.id.a_1);
        ImageButton b2 = (ImageButton)findViewById(R.id.a_2);
        ImageButton b3 = (ImageButton)findViewById(R.id.a_3);
        ImageButton b4 = (ImageButton)findViewById(R.id.a_4);
        ImageButton b5 = (ImageButton)findViewById(R.id.a_5);
        ImageButton b6 = (ImageButton)findViewById(R.id.a_6);
        ImageButton b7 = (ImageButton)findViewById(R.id.a_7);
        ImageButton b8 = (ImageButton)findViewById(R.id.a_8);
        ImageButton b9 = (ImageButton)findViewById(R.id.a_9);
        ImageButton b10 = (ImageButton)findViewById(R.id.a_10);
        ImageButton b11 = (ImageButton)findViewById(R.id.a_11);
        ImageButton b12 = (ImageButton)findViewById(R.id.a_12);
        ImageButton  find = (ImageButton)findViewById(R.id.find);

        find.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),Menu.class);
                startActivity(intent);
            }
        });
        b1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                        Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b7.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b10.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b11.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
        b12.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent
                        (getApplicationContext(), // 현재 화면의 제어권자
                                Grid.class); // 다음 넘어갈 클래스 지정
                startActivity(intent); // 다음 화면으로 넘어간다
            }
        });
    } // end onCreate()
 // end MainActivity

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case 0:
                    menus.clear();
                    adapter.notifyDataSetChanged();
                    adapterGrid.notifyDataSetChanged();
                    break;
            }
        }
    }

    @Override
    public void onBackPressed() {
        long current = System.currentTimeMillis();
        if (current - millis <= 2000L) {
            super.onBackPressed();
        } else {
            millis = current;
            Toast.makeText(this, R.string.exit, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        for (String message : getNfcMessages()) {
            //  Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            try {
                JSONObject object = new JSONObject(message.indexOf("en") == 0 ? message.substring(2) : message);
                if (!object.isNull("_index")) {
                    _index = object.getInt("_index");
                    get();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

    }

    private void get() {
        @SuppressLint("StaticFieldLeak")
        class Select extends AsyncTask<String, Void, String> {
            private Dialog dialog;

            @Override
            protected String doInBackground(String... params) {
                try {
                    String link = F.SERVER_IP.concat("get_all_menu.php");
                    String data = URLEncoder.encode("restaurant", "UTF-8") + "=" + URLEncoder.encode(params[0], "UTF-8");
                    data += "&" + URLEncoder.encode("keyword", "UTF-8") + "=" + URLEncoder.encode(params[1], "UTF-8");

                    URL url = new URL(link);
                    URLConnection connection = url.openConnection();
                    connection.setDoOutput(true);

                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
                    writer.write(data);
                    writer.flush();

                    StringBuilder builder = new StringBuilder();
                    String s;
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    while ((s = reader.readLine()) != null) {
                        builder.append(s);
                    }

                    return builder.toString().trim();
                } catch (Exception e) {
                    return e.getMessage();
                }
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                dialog = new Dialog(activity, R.style.MyDialog);
                dialog.setCancelable(true);
                dialog.addContentView(new ProgressBar(activity), new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                dialog.show();
            }

            @SuppressLint("DefaultLocale")
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                Log.i(getPackageName(), s);

                dialog.dismiss();
                adapter.clear();
                menus.clear();
                try {
                    JSONArray array = new JSONArray(s);
                    for (int i = 0; i < array.length(); i++) {
                        adapter.add(array.getJSONObject(i));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                adapter.notifyDataSetChanged();
                adapterGrid.notifyDataSetChanged();
            }
        }

        Select select = new Select();
        select.execute(String.valueOf(_index), "");
    }

    public static String getMACAddress(String interfaceName) {
        try {
            List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
            for (NetworkInterface intf : interfaces) {
                if (interfaceName != null) {
                    if (!intf.getName().equalsIgnoreCase(interfaceName)) continue;
                }

                byte[] mac = intf.getHardwareAddress();
                if (mac == null) return "";

                StringBuilder buf = new StringBuilder();
                for (byte aMac : mac) buf.append(String.format("%02X:", aMac));
                if (buf.length() > 0) buf.deleteCharAt(buf.length() - 1);

                return buf.toString();
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return "";
    }

    private void put(final int _index, final View v) {
        @SuppressLint("StaticFieldLeak")
        class Insert extends AsyncTask<String, Void, String> {
            private Dialog dialog;

            @Override
            protected String doInBackground(String... params) {
                try {
                    String link = F.SERVER_IP.concat("put_like.php");
                    URL url = new URL(link);
                    URLConnection connection = url.openConnection();
                    connection.setDoOutput(true);

                    String data = URLEncoder.encode("_index", "UTF-8") + "=" + URLEncoder.encode(params[0], "UTF-8");
                    data += "&" + URLEncoder.encode("address", "UTF-8") + "=" + URLEncoder.encode(params[1], "UTF-8");
                    OutputStreamWriter writer = new OutputStreamWriter(connection.getOutputStream());
                    writer.write(data);
                    writer.flush();

                    StringBuilder builder = new StringBuilder();
                    String s;
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    while ((s = reader.readLine()) != null) {
                        builder.append(s);
                    }

                    return builder.toString().trim();
                } catch (Exception e) {
                    return e.getMessage();
                }
            }

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

                dialog = new Dialog(activity, R.style.MyDialog);
                dialog.setCancelable(true);
                dialog.addContentView(new ProgressBar(activity), new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                dialog.show();
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                Log.i(getPackageName(), s);

                dialog.dismiss();
                /*try {
                    JSONObject object = new JSONObject(s);
                    ScalableLayout layout = (ScalableLayout) v.getParent();
                    TextView tvGreatCount = (TextView) layout.findViewById(R.id.great_count);
                    tvGreatCount.setText(String.valueOf(object.getInt("count")));
                } catch (JSONException e) {
                    e.printStackTrace();
                }*/
            }
        }

        Insert insert = new Insert();
        insert.execute(String.valueOf(_index), macAddress);
    }

    @Override
    public void onClick(View view) {

    }
}
