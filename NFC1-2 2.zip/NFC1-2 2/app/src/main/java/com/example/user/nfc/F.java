package com.example.user.nfc;

class F {
    static final String SERVER_IP = "http://52.79.47.71/";

    static final String KEY = "AKIAIX2BET4LFQM25JFA";
    static final String SECRET = "Ga7tg0rrEQcX/3cHB1BqhJpEnsFrX5nWg1iuHQfD";

    static final String BUCKET = "ghasnfc";
}
